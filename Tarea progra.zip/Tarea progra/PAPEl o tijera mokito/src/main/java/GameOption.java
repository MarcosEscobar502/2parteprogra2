public enum GameOption {
    ROCK, PAPER, SCISSORS;
}
