package com.rdelgatte.pitest;

class RangeValidator {

  boolean isValid(int input) {
    return input > 0 && input <= 100;
  }
}
